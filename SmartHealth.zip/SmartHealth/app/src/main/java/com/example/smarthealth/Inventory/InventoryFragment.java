package com.example.smarthealth.Inventory;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.core.content.ContextCompat;
import android.util.TypedValue;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentResultListener;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import android.provider.MediaStore;
import android.net.Uri;
import com.example.smarthealth.R;

public class InventoryFragment extends Fragment {
    private ArrayList<MedicineButton> pillsContainers;
    private ArrayList<MedicineButton> liquidsContainers;
    private ArrayList<MedicineButton> othersContainers;
    private MedicineAdapter pillsAdapter;
    private MedicineAdapter liquidsAdapter;
    private MedicineAdapter othersAdapter;
    private RecyclerView pillsLayout;
    private RecyclerView liquidsLayout;
    private RecyclerView othersLayout;
    private View view;
    private SVMInventory sharedViewModel;
    private ArrayList<MedicineTag> allTags;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.inventory_fragment, container, false);

        sharedViewModel = new ViewModelProvider(requireActivity()).get(SVMInventory.class);

        // Retrieve the information stored in sharedViewModel
        pillsContainers = sharedViewModel.getPillsButtonList();
        liquidsContainers = sharedViewModel.getLiquidsButtonList();
        othersContainers = sharedViewModel.getOthersButtonList();

        // Create adapters for each category
        pillsAdapter = new MedicineAdapter(requireContext(), pillsContainers);
        liquidsAdapter = new MedicineAdapter(requireContext(), liquidsContainers);
        othersAdapter = new MedicineAdapter(requireContext(), othersContainers);

        // Get respective layout
        pillsLayout = view.findViewById(R.id.pillsRV);
        liquidsLayout = view.findViewById(R.id.liquidsRV);
        othersLayout = view.findViewById(R.id.othersRV);

        // Create grid layout for each layout
        GridLayoutManager pillsManager = new GridLayoutManager(requireContext(), 2);
        GridLayoutManager liquidsManager = new GridLayoutManager(requireContext(), 2);
        GridLayoutManager othersManager = new GridLayoutManager(requireContext(), 2);

        // Set grid as the layout manager for each recycler view
        // Set the respective adapter
        pillsLayout.setLayoutManager(pillsManager);
        pillsLayout.setAdapter(pillsAdapter);

        liquidsLayout.setLayoutManager(liquidsManager);
        liquidsLayout.setAdapter(liquidsAdapter);

        othersLayout.setLayoutManager(othersManager);
        othersLayout.setAdapter(othersAdapter);

        // Placeholder button
        ImageButton pillsButton = view.findViewById(R.id.fillByScan);
        ImageButton fillFormButton = view.findViewById(R.id.fillForm);
        ImageButton othersButton = view.findViewById(R.id.fillFormByHistory);

        // Toggle Buttons
        ImageView togglePills = view.findViewById(R.id.pillsCollapse);
        ImageView toggleLiquids = view.findViewById(R.id.liquidsCollapse);
        ImageView toggleOthers = view.findViewById(R.id.othersCollapse);

        togglePills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(pillsAdapter != null){
                    pillsAdapter.toggleItemLimits();
                }
                ImageView pillsCollapse = view.findViewById(R.id.pillsCollapse);
                if(pillsAdapter.getIsExpanded()){
                    pillsCollapse.setImageResource(R.drawable.arrow_up);
                }
                else{
                    pillsCollapse.setImageResource(R.drawable.arrow_down);
                }
            }
        });

        toggleLiquids.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(liquidsAdapter != null){
                    liquidsAdapter.toggleItemLimits();
                }
                ImageView liquidsCollapse = view.findViewById(R.id.liquidsCollapse);
                if(liquidsAdapter.getIsExpanded()){
                    liquidsCollapse.setImageResource(R.drawable.arrow_up);
                }
                else{
                    liquidsCollapse.setImageResource(R.drawable.arrow_down);
                }
            }
        });

        toggleOthers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(othersAdapter != null){
                    othersAdapter.toggleItemLimits();
                }
                ImageView othersCollapse = view.findViewById(R.id.othersCollapse);
                if(othersAdapter.getIsExpanded()){
                    othersCollapse.setImageResource(R.drawable.arrow_up);
                }
                else{
                    othersCollapse.setImageResource(R.drawable.arrow_down);
                }
            }
        });

        // Set button click for respective buttons
        pillsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add placeholder medicine to pills category
                addMedicineToLayout("Pills","PlaceHolder", "Fever", 100,
                        ContextCompat.getDrawable(requireContext(), R.drawable.app_logo), "info", "Pills");
                Toast.makeText(requireContext(), "New Other Medicine Added", Toast.LENGTH_SHORT).show();
            }
        });

        fillFormButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FormPopUpFragment formFragment = new FormPopUpFragment();
                FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
                // Replace current fragment with the form fragment
                transaction.replace(R.id.fragmentContainer, formFragment);
                transaction.addToBackStack(null); // Add to back stack

                // Commit the transaction
                transaction.commit();

            }
        });



        othersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add placeholder medicine to others category
                addMedicineToLayout("Others","PlaceHolder", "Fever", 100,
                        ContextCompat.getDrawable(requireContext(), R.drawable.app_logo), "info", "Others");
                Toast.makeText(requireContext(), "New Other Medicine Added", Toast.LENGTH_SHORT).show();
            }
        });

        getParentFragmentManager().setFragmentResultListener("formData", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(String requestKey, Bundle result) {
                if (result != null) {
                    String mediName = result.getString("mediName");
                    String mediDesc = result.getString("mediDesc");
                    int mediAmount = result.getInt("mediAmount");
                    String info = result.getString("info");
                    String mediType = result.getString("mediType");
                    byte[] byteArray = result.getByteArray("image");

                    Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                    Drawable mediImage = new BitmapDrawable(getResources(), bitmap);

                    // Add the received medicine to the layout
                    addMedicineToLayout(mediType, mediName, mediDesc, mediAmount, mediImage, info, mediType);
                }
            }
        });









        return view;

    }
    public void addMedicineToLayout(String category, String mediName, String mediDesc, int mediAmount, Drawable mediImage, String info, String type) {
        ArrayList<MedicineButton> containerList = new ArrayList<>();
        MedicineAdapter adapter = null;

        if(category.equals("Pills")){
            containerList = pillsContainers;
            adapter = pillsAdapter;
            Toast.makeText(requireContext(), "New Pill added!", Toast.LENGTH_SHORT).show();

        }
        else if(category.equals("Liquids")){
            containerList = liquidsContainers;
            adapter = liquidsAdapter;
            Toast.makeText(requireContext(), "New Liquid added!", Toast.LENGTH_SHORT).show();

        }
        else{
            containerList = othersContainers;
            adapter = othersAdapter;
            Toast.makeText(requireContext(), "New Medicine added!", Toast.LENGTH_SHORT).show();

        }
        // Add placeholder medicine button
        MedicineButton newButton = new MedicineButton(mediName, mediDesc, mediAmount, mediImage, info, type);
        // Add the placeholder to the appropriate container list
        containerList.add(newButton);

        // Update medicine List such that when new button is added, it will be added to sublist
        adapter.updateMedicineList(containerList);

        // Notify the adapter that the data has changed
        adapter.notifyDataSetChanged();
    }

}





