package com.example.smarthealth.Inventory;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smarthealth.R;

import java.io.ByteArrayOutputStream;

public class FormPopUpFragment extends Fragment {
    private ActivityResultLauncher<Intent> galleryLauncher;
    private ActivityResultLauncher<Intent> cameraLauncher;
    private Uri camUri;
    private ImageView popupImageView;
    private View view;

    private Button uploadImageButton, openCameraButton, confirmButton;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.form_fillup, container, false);
        if (getActivity() != null) {
            getActivity().findViewById(R.id.navbarCameraBtn).setVisibility(View.GONE);
            getActivity().findViewById(R.id.linearLayout2).setVisibility(View.GONE);
        }
        popupImageView = view.findViewById(R.id.image);


        galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == requireActivity().RESULT_OK && result.getData() != null) {
                        Uri imageUri = result.getData().getData();
                        if (popupImageView != null) {
                            // Update the popup's ImageView
                            popupImageView.setImageURI(imageUri);
                            uploadImageButton.setVisibility(View.GONE);
                            openCameraButton.setVisibility(View.GONE);
                        } else {
                            Toast.makeText(requireContext(), "Popup not open!", Toast.LENGTH_SHORT).show();}
                    } else {
                        Toast.makeText(requireContext(), "No Image Selected", Toast.LENGTH_SHORT).show();}
                }
        );


        cameraLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    if (camUri != null) {
                        popupImageView.setImageURI(camUri); // Set image from saved URI
                        uploadImageButton.setVisibility(View.GONE);
                        openCameraButton.setVisibility(View.GONE);
                    }
                    else{
                        Toast.makeText(requireContext(), "Popup not open!", Toast.LENGTH_SHORT).show();}
                }
                else {
                    Toast.makeText(requireContext(), "No Image Selected", Toast.LENGTH_SHORT).show();}
            }
        });

        openCameraButton = view.findViewById(R.id.open_camera);

        openCameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickCamera();
            }
        });


        Spinner category = view.findViewById(R.id.category);
        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView selectedText = (TextView) view;
                // Change the text color of the selected item
                selectedText.setTextColor(Color.BLACK);
                // Change the text size of the selected item (e.g., 20sp)
                selectedText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                requireContext(),
                R.array.formMediCategory,
                android.R.layout.simple_spinner_item
        );
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category.setAdapter(spinnerAdapter);

//        allTags = new ArrayList<>();
//        allTags.add(new MedicineTag("Cough",Color.BLACK));
//        allTags.add(new MedicineTag("Flu",Color.CYAN));
//        allTags.add(new MedicineTag("Headache",Color.MAGENTA));

//        Spinner tagSpinner = view.findViewById(R.id.multiSelectSpinner);
//        boolean[] selectedItems = new boolean[allTags.size()];
//        ArrayList<MedicineTag> selectedTags = new ArrayList<>();
        // Exit button to close popup window
        Button exitButton = view.findViewById(R.id.exit);
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getParentFragmentManager().popBackStack();
                getActivity().findViewById(R.id.navbarCameraBtn).setVisibility(View.VISIBLE);
                getActivity().findViewById(R.id.linearLayout2).setVisibility(View.VISIBLE);

            }}
        );

        uploadImageButton = view.findViewById(R.id.upload_image);
        uploadImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickImage();
            }}
        );


        confirmButton = view.findViewById(R.id.confirm);
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO retrieve information from the popup window
                EditText nameView = view.findViewById(R.id.formMediName);
                EditText amountView = view.findViewById(R.id.formMediAmount);
                EditText descView = view.findViewById(R.id.formMediDesc);
                ImageView imageView = view.findViewById(R.id.image);
                String mediType = category.getSelectedItem().toString();
                EditText mediInfo = view.findViewById(R.id.formMediInfo);

                String mediName = nameView.getText().toString().trim();
                String mediDesc = descView.getText().toString().trim();
                String amount = amountView.getText().toString().trim();
                Drawable image = imageView.getDrawable();
                String info = mediInfo.getText().toString().trim();

                // Pass corresponding parameters
                if (mediName.isEmpty() || mediDesc.isEmpty() || amount.isEmpty() || imageView.getDrawable() == null || info.isEmpty()) {
                    if (mediName.isEmpty()) {
                        nameView.setError("Required");
                    }
                    if (mediDesc.isEmpty()) {
                        descView.setError("Required");
                    }
                    if (amount.isEmpty()) {
                        amountView.setError("Required");
                    }
                    if (info.isEmpty()) {
                        mediInfo.setError("Required");
                    }
                    if (imageView.getDrawable() == null) {
                        Toast.makeText(requireContext(), "Please select an image!", Toast.LENGTH_SHORT).show();
                    }
                    return;
                } else {
                    String encodedImage = encodeDrawableToBase64(image);
                    Bundle result = new Bundle();
                    result.putString("mediName", mediName);
                    result.putString("mediDesc", mediDesc);
                    result.putString("amount", amount);
                    result.putString("info", info);
                    result.putString("mediType", mediType);
                    result.putString("image", encodedImage);
                    getParentFragmentManager().setFragmentResult("formData", result);

                    getParentFragmentManager().popBackStack();
                    getActivity().findViewById(R.id.navbarCameraBtn).setVisibility(View.VISIBLE);
                    getActivity().findViewById(R.id.linearLayout2).setVisibility(View.VISIBLE);
                }
            }
        });

        return view;
    }


        private void setupTagSelection() {
            // Your tag selection logic can go here, similar to the Fragment version.
            // If you want to use a multi-choice dialog to select tags, you can implement it in a similar way.
        }

        private void pickImage() {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            galleryLauncher.launch(intent);
        }

        private void pickCamera() {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.TITLE, "New Medicine");
            values.put(MediaStore.Images.Media.DESCRIPTION, "Camera");
            camUri = requireContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
            cameraLauncher.launch(cameraIntent);
        }
    private String encodeDrawableToBase64(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] byteArray = stream.toByteArray();
            return Base64.encodeToString(byteArray, Base64.DEFAULT);
        }
        return null;
    }

}




