package com.example.smarthealth.Inventory;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import com.example.smarthealth.R;
import java.util.List;

public class TagAdapter extends ArrayAdapter<MedicineTag> {
    private Context context;
    private List<MedicineTag> tagList;

    public TagAdapter(Context context, List<MedicineTag> mediTagList) {
        super(context, 0, mediTagList);
        this.context = context;
        this.tagList = mediTagList;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        return createView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, @NonNull ViewGroup parent) {
        return createView(position, convertView, parent);
    }

    private View createView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.tag_item, parent, false);
        }

        MedicineTag mediTag = tagList.get(position);
        TextView textView = (TextView) convertView;
        textView.setText(mediTag.getName());
        textView.setBackgroundColor(mediTag.getBackgroundColour());

        return convertView;
    }
}
